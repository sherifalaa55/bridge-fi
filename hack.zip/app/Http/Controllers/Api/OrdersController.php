<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Order;
use App\OrderItem;
use App\Product;
use Illuminate\Http\Request;

class OrdersController extends Controller
{
    
    public function createOrder(Request $request)
    {
        $this->validate($request, [
            "orders.*.user_name" => "required",
            "orders.*.user_phone" => "required",
            "orders.*.user_address" => "required",
            "orders.*.order_date" => "required",
            "orders.*.items" => "required"
        ]);

    	foreach ($request->orders as $order) {
    		$newOrder = new Order;
    		$newOrder->user_name = $order["user_name"];
    		$newOrder->user_phone = $order["user_phone"];
    		$newOrder->user_address = $order["user_address"];
            // dd(strtotime($order["order_date"]));
    		$newOrder->order_date = date("Y-m-d H:i:s", strtotime($order["order_date"]));
            $newOrder->unique_id = $order["unique_id"];
    		$newOrder->save();

    		foreach ($order["items"] as $item) {
    			$orderItem = new OrderItem;
    			$product = Product::find($item["product_id"]);
    			$orderItem->product_id = $product->id;
    			$orderItem->price = $product->price;
    			$orderItem->quantity = $item["quantity"];
                $orderItem->order_id = $newOrder->id;
    			$orderItem->save();
    		}
    	}

    	return $this->jsonResponse("Success");
    }
}
